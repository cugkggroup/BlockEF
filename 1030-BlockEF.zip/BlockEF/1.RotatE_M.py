import torch
import numpy as np
import random
import torch.nn as nn
import torch.optim as optim
import sys
model = "RotatE"#RotatE实体分为实部和虚部
data1 = "WN18RR"#
data2 = "FB15K237"
ga = "1"
dim = 1000#1000 1500
epoch1 = 80000
epoch2 = 100000
item = ["1","2","4","5"]
for ga in item:
    data_path1 = "./models/"+model+'_'+data1+'_'+str(epoch1)+'_'+str(dim)
    data_path2 = "./models/"+model+'_'+data2+'_'+str(epoch2)+'_'+str(dim)
    ent1 = np.load(data_path1+'/entity_embedding.npy')
    rel1 = np.load(data_path1+'/relation_embedding.npy')
    ent2 = np.load(data_path2+'/entity_embedding.npy')
    rel2 = np.load(data_path2+'/relation_embedding.npy')
    print(ent1.shape,ent2.shape,rel1.shape,rel2.shape)

    Tent_embeddings = torch.tensor(ent1)
    Tent_embeddings1 = torch.tensor(ent2)
    ent1 = torch.tensor(ent1)
    ent2 = torch.tensor(ent2)
    rel1 = torch.tensor(rel1)
    rel2 = torch.tensor(rel2)
    info_path="./benchmarks/"+data2+'_'+data1 +"/"+ga+"/"#设置数据文件夹
    trainDate=[]#实体对训练数据
    trainDatex=[]
    trainDatey=[]
    testDate=[]#实体对测试集数据
    testDatex=[]#实体对测试集数据
    testDatey=[]#实体对测试集数据
    EP_all=[]#所有对齐实体
    def readfile():#读取文件数据
        #第一层数据导入
        file1=open(info_path + 'common_entity_info.txt',"r+")#读取训练种子对
        # file1.readline()#读取第一行数字 不需要！！
        while True:
            line=file1.readline()
            if not line:
                file1.close()
                break
            line = line.split()
    #         print(line)
            trainDate.append([int(line[0]),int(line[1])])#e. e1
            trainDatex.append(int(line[0]))
            trainDatey.append(int(line[1]))
    #         testDate.append([int(line[0]),int(line[1])])#e. e1
            EP_all.append([int(line[0]),int(line[1])])

    readfile()
    import random
    import torch.nn as nn
    import torch.optim as optim
    import sys
    tong=[]#不同变化通道
    outr=[]
    trainTimes = 10000#基向量预训练次数
    LearningRate=0.001
    Tent_embeddings=Tent_embeddings.clone().detach()
    Tent_embeddings1=Tent_embeddings1.clone().detach()
    re_Tent_embeddings, im_Tent_embeddings = torch.chunk(Tent_embeddings, 2, dim=1)
    re_Tent_embeddings1, im_Tent_embeddings1 = torch.chunk(Tent_embeddings1, 2, dim=1)
    x1 = Tent_embeddings[trainDatex].cuda()
    y1 = Tent_embeddings1[trainDatey].cuda()

    class getline(nn.Module):
        def __init__(self):
            super(getline,self).__init__()
            self.w1 = nn.Parameter(torch.rand(dim))
            
        def forward(self,x1,y1):#x1,y1为正例，x2,y2为负例
            x1 = x1.view(-1,dim)
            y1 = y1.view(-1,dim)
            # print(x1)
            # print(self.w1)
            pre=x1*self.w1
            C=torch.norm(y1-pre,p=2,dim=1)#将2范数作为损失值
            C=torch.sum(C)
            score=C
            return score
        def out(self,x1):
            x1 = x1.view(-1,dim)
            pre=x1*self.w1
            return pre

    mod = getline().cuda()
    optimizer = optim.SGD(mod.parameters(),LearningRate)
    for epoch in range(trainTimes):
        # print(epoch)
        score = mod.forward(x1,y1)
        loss=score.item()
        total_loss = loss
        mod.zero_grad()
        score.backward(retain_graph=True)
        optimizer.step()
        if(epoch%2000==0):
            print(epoch,"loss: ",total_loss)
    nent1=mod.out(torch.tensor(ent1).cuda()).cpu().clone().detach()
    if(model == "RotatE"):
        re_head, re_tail = torch.chunk(ent1, 2, dim=1)
        nre_head=mod.out(re_head.cuda()).cpu().clone().detach()
        nre_tail=mod.out(re_tail.cuda()).cpu().clone().detach()
        nent1 = torch.cat((nre_head, nre_tail), dim=1)
    if(model == "PairRE" or model == "TranSHER" ):#
        re_head, re_tail = torch.chunk(rel1, 2, dim=1)
        nre_head=mod.out(re_head.cuda()).cpu().clone().detach()
        nre_tail=mod.out(re_tail.cuda()).cpu().clone().detach()
        nrele1 = torch.cat((nre_head, nre_tail), dim=1)
        print(rel1.shape,nrele1.shape)
    else:
        nrele1=mod.out(torch.tensor(rel1).cuda()).cpu().clone().detach()
        print(rel1.shape,nrele1.shape)
    print("映射完成")

    f=open(info_path+"/big/entity2id.txt","r")#读取大图谱实体数量
    entnum = int(f.readline())
    f.close()
    f=open(info_path+"/big/relation2id.txt","r")#读取大图谱关系数量
    relnum = int(f.readline())
    f.close()
    f=open("./benchmarks/WN18RR/entity2id.txt","r")#读取大图谱实体数量
    entnum1 = int(f.readline())
    f.close()
    f=open("./benchmarks/WN18RR/relation2id.txt","r")#读取大图谱关系数量
    relnum1 = int(f.readline())
    f.close()

    entState = torch.zeros(entnum)
    relState = torch.zeros(relnum)
    outent = torch.zeros(entnum,dim)
    outrel = torch.zeros(relnum,dim)
    if(model == "RotatE"):
        print("RotatE")
        outent = torch.zeros(entnum,dim*2)
    if(model == "PairRE" or model == "TranSHER" ):#
        outrel = torch.zeros(relnum,dim*2)

    print("输出结果：",outent.shape,outrel.shape)
    common_entity_info ={}#大图谱中实体编号 对于fb15237中旧实体编号
    file1=open(info_path + '/common_entity_info.txt',"r+")#读取训练种子对
        # file1.readline()#读取第一行数字 不需要！！
    while True:
        line=file1.readline()
        if not line:
            file1.close()
            break
        line = line.split()
    #         print(line)
        common_entity_info[int(line[0])] = int(line[1])
    uncommon_relation_dict ={}#新编号 旧 
    file1=open(info_path + '/uncommon_relation_dict.txt',"r+")#读取训练种子对
        # file1.readline()#读取第一行数字 不需要！！
    while True:
        line=file1.readline()
        if not line:
            file1.close()
            break
        line = line.split()
    #         print(line)
        uncommon_relation_dict[int(line[1])] = int(line[0])
    uncommon_entity_dict ={}#新编号 旧 
    file1=open(info_path + '/uncommon_entity_dict.txt',"r+")#读取训练种子对
    while True:
        line=file1.readline()
        if not line:
            file1.close()
            break
        line = line.split()
    #         print(line)
        uncommon_entity_dict[int(line[1])] = int(line[0])
    Norel = []#不变实体编号
    Noent = []#不变实体编号
    for i in range(relnum):
        if(i<relnum1):
            outrel[i] = nrele1[i]
        else:
            # print(i,uncommon_relation_dict[i])
            Norel.append(i)
            outrel[i] = rel2[uncommon_relation_dict[i]]
    for item in common_entity_info:#公共实体以graph2中向量为主
        entState[item]=1#已经赋值
        # print(outent[item].shape, ent2[common_entity_info[item]].shape)
        outent[item] = ent2[common_entity_info[item]]
        Noent.append(item)
    for i in range(entnum1):
        if(entState[i]!=1):
            outent[i] = nent1[i]
            entState[i]=1
    for i in range(entnum1,entnum):
        outent[i] = ent2[uncommon_entity_dict[i]]
        entState[i]=1
        Noent.append(i)
    print(torch.sum(entState),entnum)
    file = open(info_path + model+"_"+ga+"_Arelinfo.txt", "w+")
    for key in Norel:
        file.write(str(key)+"\n")#big中的编号，graph2中的编号
    file.close()
    file = open(info_path + model+"_"+ga+"_Aentinfo.txt", "w+")
    for key in Noent:
        file.write(str(key)+"\n")#big中的编号，graph2中的编号
    file.close()
    np.save(info_path+model+"_"+ga+'_entity_embedding_hebing',outent.numpy())
    np.save(info_path+model+"_"+ga+'_relation_embedding_hebing',outrel.numpy())
print("完成")  
