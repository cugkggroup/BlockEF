数据说明：
实验数据集对应四组A、B、C、D
分别对应BlockEF\benchmarks\FB15K237_WN18RR下1、2、4、5数据文件夹
数据集地址：链接：https://pan.baidu.com/s/1Gvp5rWxZ6pa3OvXGZZsB3g?pwd=wtmc  提取码：wtmc

基础准备：
使用TranSHER.zip开源代码训练对应的模型得到FB15K237和WN18RR的嵌入结果，使用推荐的参数命令即可
实验结果文件夹命名规则：模型名称_数据集名称_训练轮次_嵌入维度（如：TransE_WN18RR_80000_1000），将训练结果文件夹整体移动到BlockEF\models文件夹下

实验过程：
1.运行1.TransE_M.py,进行转化固定
2.终端运行命令 bash run.sh train TransE FB15K237_WN18RR/1/bign 0 0 1024 256 1000 9.0 1.0 0.00005 20000 8
进行微调优化得到嵌入融合结果，并进行链路预测实验。
其模型和数据集修改对应的参数指令即可，注意不同模型的嵌入维度和训练轮次不同，一般为完整训练的20%左右，嵌入维度
设置BlockEF\codes\model.py 文件夹中参数变量ga为对应的实验数据文件夹编号（1、2、4、5）

