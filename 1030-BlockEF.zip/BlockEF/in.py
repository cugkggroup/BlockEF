model = "TransE"# RotatE PairRE TranSHER
    data = "WN18RR"
    dim = 1000
    epoch = 80000
    ga = "1"
    data = data +ga
    info_path = "./benchmarks/"+data+"/graph1"
    data_path = "./models/"+model+'_'+data+'/'+"graph1_"+str(epoch)+'_'+str(dim)
    data_path2 = "./models/"+model+'_'+data+'/'+"graph2_"+str(epoch)+'_'+str(dim)
    file=open(info_path + '/entity2id.txt', encoding='utf-8')
    nentity=int(file.readline())# entity number of datset
    file.close()
    file=open(info_path + '/relation2id.txt', encoding='utf-8')
    nrelation=int(file.readline())# entity number of datset
    file.close()
    argparse_dict = {}
    with open(os.path.join(data_path, 'config.json'), 'r') as fjson:
            argparse_dict = json.load(fjson)
    print('Model: %s' % model)
    print('Data Path: %s' % data_path)
    print('#entity: %d' % nentity)
    print('#relation: %d' % nrelation)
    train_triples = []#(h,r,t)
    train_triples = readfile(os.path.join(info_path, 'train2id.txt'))
    print('#train: %d' % len(train_triples))
    valid_triples = readfile(os.path.join(info_path, 'valid2id.txt'))
    print('#valid: %d' % len(valid_triples))
    test_triples = readfile(os.path.join(info_path, 'test2id.txt'))
    print('#test: %d' % len(test_triples))
    
    #All true triples
    all_true_triples = train_triples + valid_triples + test_triples

    kge_model = KGEModel(
        model_name=model,
        nentity=nentity,
        nrelation=nrelation,
        hidden_dim=dim,
        gamma=argparse_dict['gamma'],
        double_entity_embedding=argparse_dict['double_entity_embedding'],
        double_relation_embedding=argparse_dict['double_relation_embedding']
    )
    kge_model = kge_model.cuda()
    checkpoint = torch.load(os.path.join(data_path, 'checkpoint'))
    kge_model.load_state_dict(checkpoint['model_state_dict'])
